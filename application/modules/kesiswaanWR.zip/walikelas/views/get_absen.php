 
<?php

	
	$tgl = $this->tanggal->eng_($_POST['tgl'], "-");

	$get = $this->mdl->jadwal_mapel($tgl)->result();

	$mapel = "";
	foreach ($get as $v) {

		$nsiswa = $this->mdl->kehadiran_permapel($v->id, $tgl)->num_rows();
		$siswa = $this->mdl->kehadiran_permapel($v->id, $tgl)->result();


		if ($nsiswa != 0) {
			
			

			$dt = "";
			$n = 1;
			foreach ($siswa as $vs) {
				$dt .= "
					<tr>
						<td>".$n."</td>
						<td>
							<a href='javascript:vid(0)' onclick='detail(`".$vs->id."`)' >
								".$this->m_reff->goField("data_siswa","nama","where id='".$vs->id."'")."
								<br>
								<span class='col-pink'>".$this->m_reff->goField("v_kelas","nama","where id='".$vs->id_kelas."'")."</span>
							</a>
						</td>
						<td>".$this->mdl->cekStatusHadirAbsenMapel($vs->id, $v->id)."</td>
					</tr>
				";

				$n++;
			}

		}
		else{
			$dt = "<tr><td colspan='3' align='center'><i>hadir semua.</i></td></tr>";
		}





		$mapel .= "

			<div class='card'>
			    <div  >
			        
			        <span class='col-pink' style='margin-left:5px'>	Mapel : ".$this->m_reff->goField("tr_mapel", "nama", " WHERE id='".$v->id_mapel."' ")." </span> |
			         <span class='col-brown'>	Jam ke : ".substr($v->jam, 1, -1)."</span> | 
			         <span class='col-indigo'>	Guru : ".$this->m_reff->goField("data_pegawai", "nama", " WHERE id='".$v->id_guru."' ")."</span>
			        
			    </div>
			    <div class='body entry'>
			    	<div class='table-responsive'>
			    		<table>
			    			<thead>
			    				<th width='10%'>NO</th>
			    				<th>NAMA & KELAS</th>
			    				<th width='10%'>KEHADIRAN</th>
			    			</thead>
			    			<tbody>
			    				".$dt."
			    			</tbody>
			    		</table>
			    	</div>
			    </div>
			</div>
		";

	}


	echo $mapel;
?>

